
Pareja 7 Grupo 1311:

Espinosa Pérez, Alberto
Rodriguez Aviles, Pelayo

Para generar ejecutable alfa y generar asm => make

Para compilar con nasm => make CompilarAsm

Para compilar ejecutable final => make CompilarEjecutable

Para la limpieza de ficheros objeto y demas => make clean


Entregamos la carpeta include con las librerias que han sido necesarias.

  1. alfa.h
  2. generacion.h
  3.tablaHash.h
  4.tablaSimbolos.h

Entregamos la carpeta obj con la libreria compilada albalib.o.
Entregamos la carpeta src con los ficheros que han sido necesarios.

  1. alfa.l
  2. alfa.y
  3. generacion.c
  4. main.c
  5. tablaHash.c
  6. tablaSimbolos.c

Entregamos el Makefile que ya explicamos anteriormente como se usa.

Adjuntamos el prg1.alf y prg1.asm necesarios para probar diferentes casos.
